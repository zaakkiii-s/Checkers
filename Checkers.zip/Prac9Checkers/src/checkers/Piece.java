package checkers;

import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

public class Piece {

	public static final int BLACK = 0;
	public static final int RED = 1;

	private int color;
	private Image image = null;
	private boolean isCrown = false;

	public Piece(int color) {
		// TODO display image of correct piece in the square 
		this.color = color;
		try {
			if(color == BLACK) {
				image = ImageIO.read(new File("images/black.gif"));
			}else { 
				image = ImageIO.read(new File("images/red.gif"));
			}
		}
			catch  (IOException e) {
				JOptionPane.showMessageDialog(null, "error loading imags");
			}
	}	

	public int getColor() {
		return color;
	}
	
	public boolean isCrown() {
		return isCrown;
	}

	public void draw(Graphics g, int x, int y, int height, int width) {
		// TODO draw the image in the square
		if (image != null) {
			g.drawImage(image, x, y, width, height, null);
		}
	}
	
	public void makeCrown() {
		// TODO display image of the correct king piece in the square
		
		    isCrown = true;
		    try {
		        // Load a special crowned image based on the piece's color.
		        if (color == BLACK) {
		            image = ImageIO.read(new File("images/blackcrown.gif"));
		        } else {
		            image = ImageIO.read(new File("images/redcrown.png"));
		        }
		    } catch (IOException e) {
		        // Display an error message dialog if the crowned image fails to load.
		        JOptionPane.showMessageDialog(null, "Error loading crown image: " + e.getMessage(), "Image Load Error", JOptionPane.ERROR_MESSAGE);
		    }
		}

	}

