package checkers;



import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Board extends JPanel implements MouseListener {
    // Constant for the number of rows and columns in a standard checkers game (8x8 board).
    public static final int numRowCol = 8;
    // Constant representing the movement direction for upward movement (used for red pieces).
    public static final int UP = -1;
    // Constant representing the movement direction for downward movement (used for black pieces).
    public static final int DOWN = 1;

    // 2D array to represent the board, storing each square as an instance of the Square class.
    private Square[][] squares = new Square[numRowCol][numRowCol];
    // Reference to the first square selected during a move (null if no square is selected).
    private Square firstSelected = null;
    // Reference to the second square selected during a move, typically the destination (null if no second square has been selected).
    private Square secondSelected = null;
    // Boolean flag to track whose turn it is; true if it's black's turn, false if red's.
    private boolean isBlackTurn = true;
    // Counter for the number of black pieces remaining on the board.
    private int numBlackPieces = 12;
    // Counter for the number of red pieces remaining on the board.
    private int numRedPieces = 12;

    // Variable to store the current direction of movement, can be either UP or DOWN.
    private int direction;

    // Constructor for the Board class.
    public Board() {
        // Initialize isDarkSquare to true to start with a dark square on top left.
        boolean isDarkSquare = true;

        // Loop through each row of the board.
        for (int row = 0; row < numRowCol; row++) {
            // Loop through each column in the current row.
            for (int col = 0; col < numRowCol; col++) {
                // If the current square should be dark, initialize it as such.
                if (isDarkSquare) {
                    squares[row][col] = new Square(row, col, isDarkSquare);

                    // If the row is one of the first three, add a black piece to the square.
                    if (row <= 2) {
                        squares[row][col].addPiece(new Piece(Piece.BLACK));
                    }

                    // If the row is one of the last three, add a red piece to the square.
                    if (row >= 5) {
                        squares[row][col].addPiece(new Piece(Piece.RED));
                    }

                    // Toggle isDarkSquare to alternate square colors.
                    isDarkSquare = false;
                } else {
                    // For a light square, just initialize without adding any piece.
                    squares[row][col] = new Square(row, col, isDarkSquare);
                    // Toggle isDarkSquare for the next square.
                    isDarkSquare = true;
                }
            }

            // At the end of each row, toggle the starting color of the next row.
            if (row % 2 == 0) {
                isDarkSquare = false;
            } else {
                isDarkSquare = true;
            }
        }

        // Register this panel as a listener for mouse events.
        this.addMouseListener(this);
        // Set the preferred size of the board based on the number of squares and the size of each square.
        setPreferredSize(new Dimension(Square.SIZE * numRowCol, Square.SIZE * numRowCol));
    }

    // Override the paintComponent method of JPanel to customize the drawing of the Board.
    public void paintComponent(Graphics g) {
        // Call super's paintComponent to ensure proper painting of JPanel's background and other components.
        super.paintComponent(g);

        // Loop through each row of the board.
        for (int i = 0; i < numRowCol; i++) {
            // Loop through each column in the current row.
            for (int j = 0; j < numRowCol; j++) {
                // Call the draw method of the Square object at position [i][j] with the current Graphics object.
                // This method is responsible for drawing the individual square, which could be either empty or contain a piece.
                squares[i][j].draw(g);
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        // Calculate which square is clicked based on mouse coordinates and size of each square.
        Square s = squares[e.getY() / Square.SIZE][e.getX() / Square.SIZE];
        // Determine the movement direction based on whose turn it is.
        if (isBlackTurn) {
            direction = DOWN; // Black pieces move down the board
        } else {
            direction = UP; // Red pieces move up the board
        }

        // Check if no square has been selected yet
        if (this.firstSelected == null) {
            // Check if the clicked square has a piece on it
            if (s.getPiece() != null) {
                // Ensure that the player only selects a piece of the right color based on whose turn it is
                if ((s.getPiece().getColor() == Piece.BLACK && isBlackTurn)
                        || (s.getPiece().getColor() == Piece.RED && !isBlackTurn)) {
                    // Temporary variables to hold potential move locations
                    Square optionSquare1;
                    Square optionSquare2;

                    // Check if moving to the left diagonal square is out of bounds
                    if (s.getXIndex() - 1 < 0) {
                        optionSquare1 = null;
                    } else {
                        // Calculate potential move square based on direction and check left diagonal
                        optionSquare1 = squares[s.getYIndex() + 1 * direction][s.getXIndex() - 1];
                    }

                    // Check if moving to the right diagonal square is out of bounds
                    if (s.getXIndex() + 1 > squares.length - 1) {
                        optionSquare2 = null;
                    } else {
                        // Calculate potential move square based on direction and check right diagonal
                        optionSquare2 = squares[s.getYIndex() + 1 * direction][s.getXIndex() + 1];
                    }

                    // Determine if the potential moves are valid (i.e., the squares are empty or contain an opponent's piece)
                    if ((optionSquare1 != null && (optionSquare1.getPiece() == null
                            || s.getPiece().getColor() != optionSquare1.getPiece().getColor()))
                            || (optionSquare2 != null && (optionSquare2.getPiece() == null
                                    || s.getPiece().getColor() != optionSquare1.getPiece().getColor()))) {
                        // If a valid move is possible, select this piece to be moved
                        firstSelected = s;
                        System.out.println("FIRST SELECTED");
                    } else {
                        // If no valid moves are possible, indicate wrong choice
                        System.out.println("WRONG CHOICE");
                    }
                }
            }
        }
        // Select second square
        else {
            // Ensure the clicked square does not contain a piece and it's not the same as the first selected square.
            if (s.getPiece() == null && s != firstSelected) {
                // Check if the clicked square is a valid move to an adjacent diagonal square in the correct direction.
                if (firstSelected.getYIndex() - s.getYIndex() == direction * -1
                        && ((firstSelected.getXIndex() - s.getXIndex() == 1)
                                || (firstSelected.getXIndex() - s.getXIndex() == -1))) {
                    // If a valid non-capturing move is detected, mark this square as the second selected.
                    secondSelected = s;
                    System.out.println("SECOND SELECTED");
                    // Call the move method to execute the move.
                    move();
                }
                // Check if the clicked square is a valid capturing move to a diagonal square two steps away in the correct direction.
                else if (firstSelected.getYIndex() - s.getYIndex() == direction * -2
                        && ((firstSelected.getXIndex() - s.getXIndex() == 2)
                                || (firstSelected.getXIndex() - s.getXIndex() == -2))) {
                    // If a valid capturing move is detected, mark this square as the second selected.
                    secondSelected = s;
                    System.out.println("SECOND SELECTED");
                    // Call the capture method to execute the capture.
                    capture();
                }
            }
        }
    }

    public void capture() {
        Square capturedSquare = squares[firstSelected.getYIndex() - ((firstSelected.getYIndex() - secondSelected.getYIndex()) / 2)][firstSelected.getX() / Square.SIZE - ((firstSelected.getXIndex() - secondSelected.getXIndex()) / 2)];
        // Red captures black
        if (capturedSquare.getPiece().getColor() == Piece.BLACK && firstSelected.getPiece().getColor() == Piece.RED) {
            numBlackPieces--;
            capturedSquare.removePiece();
            move();
        }
        // Black captures red
        else if (capturedSquare.getPiece().getColor() == Piece.RED && firstSelected.getPiece().getColor() == Piece.BLACK) {
            numRedPieces--;
            capturedSquare.removePiece();
            move();
        }
    }

    public void move() {
        Piece p = firstSelected.getPiece();
        firstSelected.removePiece();
        secondSelected.addPiece(p);
        if ((isBlackTurn && secondSelected.getYIndex() == 7) || (!isBlackTurn && secondSelected.getYIndex() == 0)) {
            secondSelected.getPiece().makeCrown();
        }
        firstSelected = null;
        secondSelected = null;
        isBlackTurn = !isBlackTurn;
        repaint();
        checkWin();
    }

    public void checkWin() {
        if (numBlackPieces == 0) {
            JOptionPane.showMessageDialog(this, "Red wins");
            System.exit(0);
        }
        if (numRedPieces == 0) {
            JOptionPane.showMessageDialog(this, "Black wins");
            System.exit(0);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // TODO Auto-generated method stub
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // TODO Auto-generated method stub
    }
}

	